Mix Space是一个个人空间，也可以用作个人博客，功能更全面，并且会持续更新。

[实时预览](https://innei.in/)

我们有两个核心代码库。

[core](https://github.com/mx-space/mx-server)是 Mix Space 的核心服务，提供 RESTful API、cron、备份、无服务器功能等特性。
[mx-admin](https://github.com/mx-space/mx-admin)，Mix Space Server 的控制面板，风格简洁，功能全面。
现在，我们有 3 种前端风格。

[Shiro](https://github.com/Innei/Shiro)，一个极简主义的个人网站，体现了纸张的纯净和雪的清新。
kami，一款基于 MX 空间的 Web 前端设计风格。可爱又讨喜。完全支持 MX 服务器。
mx-web-yun , ☁️ 一个快速、轻便、可爱的 Mix Space 主题。 一个对可爱的自以为是的前端风格。
我们也有生态系统。

docker，一个用于快速部署 mx-space 系统的 docker-compose 文件，真棒。
api-client是一个用于 mx-space RESTful API 的 HTTP 客户端，用于快速构建新的前端项目。
imx-bot，一个带有 mx-space 事件处理程序的 QQ 机器人。
mx-tg-bot，一款适用于 Mix Space 的 Telegram 机器人。
ProcessReporterMac是一款 macOS 应用程序，可实时报告前台应用程序的名称以及正在播放的任何媒体信息。
Processforlinux，适用于 Linux 用户。
ProcessReporterWinpy、ProcessReporterWin、WinProcessReporter，适用于 Windows 用户。
文档已准备就绪。[开始](https://github.com/mx-space/docs)。